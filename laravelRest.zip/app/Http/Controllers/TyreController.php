<?php

namespace App\Http\Controllers;

use App\Http\Requests\SearchTyreRequest;
use Illuminate\Http\Request;
use App\Tyre;
use App\Gallery;
use App\Http\Resources\Tyre as TyreResource;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\DB;

class TyreController extends Controller
{

    public function index()
    {
        $tyres = Tyre::with('gallery')->get();

        return TyreResource::collection($tyres);
    }

    public function store(Request $request)
    {

        $tyre = new Tyre();
        $tyre->manufacture = $request->input('manufacture');
        $tyre->price = $request->input('price');
        $tyre->size = $request->input('size');
        $tyre->type = $request->input('type');
        $tyre->manufactureDate = $request->input('manufactureDate');

        if ($tyre->save()){
            //dd($tyre->id);
            //return new TyreResource($tyre);
        }
        $id = $tyre->id;
        $images = $request->input('image');

        foreach ($images as $image) {
            $image = base64_decode($image);
            $fileName = md5(time()).'.jpg';
            File::put($fileName, $image);
            $tyreImg = new Gallery();
            $tyreImg->tyre_id = $id;
            $tyreImg->file_name = $fileName;
            $tyreImg->save();
        }

        return new TyreResource($tyre);
    }

    public function edit(Request $request, $id)
    {
        $tyre = Tyre::findOrFail($id);

        $tyre->manufacture = $request->input('manufacture');
        $tyre->price = $request->input('price');
       // $fileName = md5(time()).'.jpg';
       // File::put($fileName, base64_decode($request->input('image')));
        $tyre->size = $request->input('size');
        $tyre->type = $request->input('type');
        $tyre->manufactureDate = $request->input('manufactureDate');

        if ($tyre->update()){
            return new TyreResource($tyre);
        }

        $id = $tyre->id;
        $images = $request->input('image');

        foreach ($images as $image) {
            $image = base64_decode($image);
            $fileName = md5(time()).'.jpg';
            File::put($fileName, $image);
            $tyreImg = new Gallery();
            $tyreImg->tyre_id = $id;
            $tyreImg->file_name = $fileName;
            $tyreImg->save();
        }

        return new TyreResource($tyre);
    }




    public function show($id)
    {
       $tyre = Tyre::findOrFail($id);
        return new TyreResource($tyre);

    }


    public function destroy($id)
    {
        $tyre = Tyre::findOrFail($id);

        if ($tyre->delete()){
            return new TyreResource($tyre);
        }

    }

    public function search(SearchTyreRequest $request)
    {

        $keyword = $request->validated();
        $exists = Tyre::where('manufacture', 'like', '%'.$keyword['keyword']. '%')->get();

        return TyreResource::collection($exists);
    }

}
