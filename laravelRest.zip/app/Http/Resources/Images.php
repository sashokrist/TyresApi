<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\File;

class Images extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    public function toArray($request)
    {
        try {
            $filePath = base64_encode(File::get(public_path($this->file_name)));
            //dd($filePath);
        } catch (\Exception $e) {
            $filePath = '';
            //dd($e->getMessage());
        }

        return [
            'tyre_id' => $this->id,
            'file_name' => $filePath,
        ];
        //return parent::toArray($request);
    }
}
