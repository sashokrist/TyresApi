<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Tyre extends Model
{

    protected $appends = [
        'main_photo'
    ];

    public function gallery(){
        return $this->hasMany(Gallery::class);
    }

    public function getMainPhotoAttribute()
    {
        if ($this->relationLoaded('gallery')) {
            return $this->gallery->where('isMain', '=', 1)->first()->file_name;
        }

        return null;
    }

    public function rules()
    {
        $this->sanitize();
        return [


        ];
    }

    public function sanitize()
    {
        $input = $this->all();

        $input['keyword'] = filter_var($input['keyword'], FILTER_SANITIZE_STRING);

        $this->replace($input);
    }

}
