<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('tyres', 'TyreController@index');

Route::get('tyre/{id}', 'TyreController@show');

Route::post('tyre', 'TyreController@store');

Route::put('tyre/{id}', 'TyreController@edit');

Route::put('tyre', 'TyreController@store');

Route::delete('tyre/{id}', 'TyreController@destroy');

Route::get('search', 'TyreController@search');

Route::get('images', 'GalleryController@index');

Route::post('images', 'GalleryController@store');




/*Route::get('image/upload','ImageUploadController@fileCreate');
Route::post('image/upload/store','ImageUploadController@fileStore');
Route::post('image/delete','ImageUploadController@fileDestroy');*/
